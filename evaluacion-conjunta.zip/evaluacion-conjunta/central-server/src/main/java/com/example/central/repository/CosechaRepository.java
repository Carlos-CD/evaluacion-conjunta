package com.example.central.repository;

import com.example.central.model.Cosecha;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CosechaRepository extends JpaRepository<Cosecha, Long> {
}
